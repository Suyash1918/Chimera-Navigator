// AST parsing utilities for React/TypeScript files
export interface ASTNode {
  type: string;
  start: number;
  end: number;
  loc?: {
    start: { line: number; column: number };
    end: { line: number; column: number };
  };
  [key: string]: any;
}

export interface ParsedComponent {
  name: string;
  astPath: string;
  hooks: ParsedHook[];
  imports: ParsedImport[];
  elements: ParsedElement[];
}

export interface ParsedHook {
  type: string;
  astPath: string;
  sourceLocation: {
    startLine: number;
    endLine: number;
  };
  variables?: string[];
  dependencies?: string[];
}

export interface ParsedImport {
  source: string;
  specifiers: string[];
  isDefault: boolean;
  astPath: string;
}

export interface ParsedElement {
  type: string;
  astPath: string;
  props: Record<string, any>;
  children: ParsedElement[];
  sourceLocation: {
    startLine: number;
    endLine: number;
  };
}

export class ASTParser {
  /**
   * Generate deterministic AST path for a node
   */
  static generateASTPath(node: ASTNode, ancestors: ASTNode[] = []): string {
    const pathParts: string[] = [];
    
    // Build path from root to current node
    [...ancestors, node].forEach((n, index) => {
      let selector = n.type;
      
      // Add identifying attributes
      if (n.type === 'FunctionDeclaration' && n.id?.name) {
        selector += `[name=${n.id.name}]`;
      } else if (n.type === 'JSXElement' && n.openingElement?.name?.name) {
        selector += `[openingElement.name=${n.openingElement.name.name}]`;
      } else if (n.type === 'VariableDeclarator' && n.id?.type) {
        selector += `[id.type=${n.id.type}]`;
      }
      
      // Add index if there are siblings of the same type
      if (index > 0) {
        const parent = ancestors[index - 1] || { body: [] };
        const siblings = this.getSiblings(parent, n.type);
        if (siblings.length > 1) {
          const siblingIndex = siblings.indexOf(n);
          selector += `[${siblingIndex}]`;
        }
      }
      
      pathParts.push(selector);
    });
    
    return '/' + pathParts.join('/');
  }

  /**
   * Get siblings of the same type from parent node
   */
  private static getSiblings(parent: ASTNode, nodeType: string): ASTNode[] {
    const children = this.getChildNodes(parent);
    return children.filter(child => child.type === nodeType);
  }

  /**
   * Get all child nodes from a parent
   */
  private static getChildNodes(node: ASTNode): ASTNode[] {
    const children: ASTNode[] = [];
    
    // Common child properties
    const childProps = ['body', 'declarations', 'elements', 'children', 'consequent', 'alternate'];
    
    for (const prop of childProps) {
      if (node[prop]) {
        if (Array.isArray(node[prop])) {
          children.push(...node[prop]);
        } else {
          children.push(node[prop]);
        }
      }
    }
    
    return children;
  }

  /**
   * Parse React hooks from AST
   */
  static parseHooks(ast: ASTNode): ParsedHook[] {
    const hooks: ParsedHook[] = [];
    
    this.traverse(ast, (node, ancestors) => {
      if (this.isHookCall(node)) {
        const hook = this.parseHookCall(node, ancestors);
        if (hook) hooks.push(hook);
      }
    });
    
    return hooks;
  }

  /**
   * Check if node is a React hook call
   */
  private static isHookCall(node: ASTNode): boolean {
    return (
      node.type === 'CallExpression' &&
      node.callee?.name?.startsWith('use') &&
      /^use[A-Z]/.test(node.callee.name)
    );
  }

  /**
   * Parse individual hook call
   */
  private static parseHookCall(node: ASTNode, ancestors: ASTNode[]): ParsedHook | null {
    const hookName = node.callee?.name;
    if (!hookName) return null;

    const astPath = this.generateASTPath(node, ancestors);
    const sourceLocation = {
      startLine: node.loc?.start.line || 0,
      endLine: node.loc?.end.line || 0,
    };

    const hook: ParsedHook = {
      type: hookName,
      astPath,
      sourceLocation,
    };

    // Parse useState specifics
    if (hookName === 'useState') {
      const parent = ancestors[ancestors.length - 1];
      if (parent?.type === 'VariableDeclarator' && parent.id?.type === 'ArrayPattern') {
        hook.variables = parent.id.elements?.map((el: any) => el?.name).filter(Boolean);
      }
    }

    // Parse useEffect dependencies
    if (hookName === 'useEffect' && node.arguments?.[1]?.type === 'ArrayExpression') {
      hook.dependencies = node.arguments[1].elements?.map((el: any) => el?.name).filter(Boolean);
    }

    return hook;
  }

  /**
   * Parse import statements from AST
   */
  static parseImports(ast: ASTNode): ParsedImport[] {
    const imports: ParsedImport[] = [];
    
    this.traverse(ast, (node, ancestors) => {
      if (node.type === 'ImportDeclaration') {
        const parsedImport = this.parseImportDeclaration(node, ancestors);
        if (parsedImport) imports.push(parsedImport);
      }
    });
    
    return imports;
  }

  /**
   * Parse individual import declaration
   */
  private static parseImportDeclaration(node: ASTNode, ancestors: ASTNode[]): ParsedImport | null {
    const source = node.source?.value;
    if (!source) return null;

    const specifiers: string[] = [];
    let isDefault = false;

    node.specifiers?.forEach((spec: any) => {
      if (spec.type === 'ImportDefaultSpecifier') {
        specifiers.push(spec.local.name);
        isDefault = true;
      } else if (spec.type === 'ImportSpecifier') {
        specifiers.push(spec.imported.name);
      }
    });

    return {
      source,
      specifiers,
      isDefault,
      astPath: this.generateASTPath(node, ancestors),
    };
  }

  /**
   * Traverse AST with visitor pattern
   */
  private static traverse(
    node: ASTNode, 
    visitor: (node: ASTNode, ancestors: ASTNode[]) => void,
    ancestors: ASTNode[] = []
  ): void {
    visitor(node, ancestors);
    
    const children = this.getChildNodes(node);
    children.forEach(child => {
      this.traverse(child, visitor, [...ancestors, node]);
    });
  }

  /**
   * Validate AST path syntax
   */
  static validateASTPath(path: string): boolean {
    // Basic validation - path should start with / and contain valid selectors
    const pathRegex = /^\/[A-Za-z][A-Za-z0-9_]*(\[[A-Za-z0-9_.=\[\]]+\])?/;
    return pathRegex.test(path);
  }

  /**
   * Generate unique element ID from AST path
   */
  static generateElementId(astPath: string): string {
    // Create a short, unique ID from the AST path
    const hash = astPath.split('').reduce((acc, char) => {
      const charCode = char.charCodeAt(0);
      return ((acc << 5) - acc + charCode) & 0xffffffff;
    }, 0);
    
    return `ast-${Math.abs(hash).toString(36)}`;
  }
}
