import type { ChimeraProject, ReactHook, ImportDependency } from "@shared/schema";

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
}

export interface ValidationError {
  path: string;
  message: string;
  code: string;
}

export interface ValidationWarning {
  path: string;
  message: string;
  code: string;
}

export class SchemaValidator {
  /**
   * Validate complete Chimera project schema
   */
  static validateProject(project: ChimeraProject): ValidationResult {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];

    // Validate required top-level fields
    if (!project.projectName) {
      errors.push({
        path: "projectName",
        message: "Project name is required",
        code: "MISSING_PROJECT_NAME"
      });
    }

    if (!project.rootDirectory) {
      errors.push({
        path: "rootDirectory", 
        message: "Root directory is required",
        code: "MISSING_ROOT_DIRECTORY"
      });
    }

    // Validate tree structure
    if (!project.tree) {
      errors.push({
        path: "tree",
        message: "Project tree is required",
        code: "MISSING_TREE"
      });
    } else {
      this.validateTreeNode(project.tree, "tree", errors, warnings);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  /**
   * Validate tree node recursively
   */
  private static validateTreeNode(
    node: any,
    path: string,
    errors: ValidationError[],
    warnings: ValidationWarning[]
  ): void {
    // Validate node type
    if (!node.type) {
      errors.push({
        path: `${path}.type`,
        message: "Node type is required",
        code: "MISSING_NODE_TYPE"
      });
    }

    // Validate node name
    if (!node.name) {
      errors.push({
        path: `${path}.name`,
        message: "Node name is required", 
        code: "MISSING_NODE_NAME"
      });
    }

    // Validate node path
    if (!node.path) {
      errors.push({
        path: `${path}.path`,
        message: "Node path is required",
        code: "MISSING_NODE_PATH"
      });
    }

    // Validate component-specific fields
    if (node.type === 'Component') {
      this.validateComponent(node, path, errors, warnings);
    }

    // Validate children recursively
    if (node.children && Array.isArray(node.children)) {
      node.children.forEach((child: any, index: number) => {
        this.validateTreeNode(child, `${path}.children[${index}]`, errors, warnings);
      });
    }
  }

  /**
   * Validate component definition
   */
  private static validateComponent(
    component: any,
    path: string,
    errors: ValidationError[],
    warnings: ValidationWarning[]
  ): void {
    // Validate fileName
    if (!component.fileName) {
      errors.push({
        path: `${path}.fileName`,
        message: "Component fileName is required",
        code: "MISSING_FILE_NAME"
      });
    } else if (!component.fileName.match(/\.(jsx|tsx)$/)) {
      warnings.push({
        path: `${path}.fileName`,
        message: "Component file should have .jsx or .tsx extension",
        code: "INVALID_FILE_EXTENSION"
      });
    }

    // Validate imports
    if (component.imports) {
      this.validateImports(component.imports, `${path}.imports`, errors, warnings);
    }

    // Validate hooks
    if (component.hooks) {
      this.validateHooks(component.hooks, `${path}.hooks`, errors, warnings);
    }

    // Validate definition
    if (component.definition) {
      this.validateDefinition(component.definition, `${path}.definition`, errors, warnings);
    }
  }

  /**
   * Validate import dependencies
   */
  private static validateImports(
    imports: any[], 
    path: string,
    errors: ValidationError[],
    warnings: ValidationWarning[]
  ): void {
    if (!Array.isArray(imports)) {
      errors.push({
        path,
        message: "Imports must be an array",
        code: "INVALID_IMPORTS_TYPE"
      });
      return;
    }

    imports.forEach((imp, index) => {
      const importPath = `${path}[${index}]`;
      
      if (!imp.source) {
        errors.push({
          path: `${importPath}.source`,
          message: "Import source is required",
          code: "MISSING_IMPORT_SOURCE"
        });
      }

      if (!imp.specifiers || !Array.isArray(imp.specifiers)) {
        errors.push({
          path: `${importPath}.specifiers`,
          message: "Import specifiers must be an array",
          code: "INVALID_SPECIFIERS_TYPE"
        });
      } else if (imp.specifiers.length === 0) {
        warnings.push({
          path: `${importPath}.specifiers`,
          message: "Import has no specifiers",
          code: "EMPTY_SPECIFIERS"
        });
      }
    });
  }

  /**
   * Validate React hooks
   */
  private static validateHooks(
    hooks: any[],
    path: string, 
    errors: ValidationError[],
    warnings: ValidationWarning[]
  ): void {
    if (!Array.isArray(hooks)) {
      errors.push({
        path,
        message: "Hooks must be an array",
        code: "INVALID_HOOKS_TYPE"
      });
      return;
    }

    hooks.forEach((hook, index) => {
      const hookPath = `${path}[${index}]`;
      
      // Validate hook type
      if (!hook.type) {
        errors.push({
          path: `${hookPath}.type`,
          message: "Hook type is required",
          code: "MISSING_HOOK_TYPE"
        });
      } else if (!hook.type.startsWith('use')) {
        warnings.push({
          path: `${hookPath}.type`,
          message: "Hook name should start with 'use'",
          code: "INVALID_HOOK_NAME"
        });
      }

      // Validate AST path
      if (!hook.astPath) {
        errors.push({
          path: `${hookPath}.astPath`,
          message: "Hook AST path is required",
          code: "MISSING_HOOK_AST_PATH"
        });
      } else if (!this.isValidASTPath(hook.astPath)) {
        errors.push({
          path: `${hookPath}.astPath`,
          message: "Invalid AST path format",
          code: "INVALID_AST_PATH"
        });
      }

      // Validate source location
      if (!hook.sourceLocation) {
        warnings.push({
          path: `${hookPath}.sourceLocation`,
          message: "Hook source location is recommended",
          code: "MISSING_SOURCE_LOCATION"
        });
      } else {
        if (typeof hook.sourceLocation.startLine !== 'number') {
          errors.push({
            path: `${hookPath}.sourceLocation.startLine`,
            message: "Start line must be a number",
            code: "INVALID_START_LINE"
          });
        }
        if (typeof hook.sourceLocation.endLine !== 'number') {
          errors.push({
            path: `${hookPath}.sourceLocation.endLine`,
            message: "End line must be a number", 
            code: "INVALID_END_LINE"
          });
        }
      }
    });
  }

  /**
   * Validate component definition
   */
  private static validateDefinition(
    definition: any,
    path: string,
    errors: ValidationError[],
    warnings: ValidationWarning[]
  ): void {
    if (!definition.rootElementType) {
      errors.push({
        path: `${path}.rootElementType`,
        message: "Root element type is required",
        code: "MISSING_ROOT_ELEMENT_TYPE"
      });
    }

    if (definition.elements) {
      this.validateElements(definition.elements, `${path}.elements`, errors, warnings);
    }
  }

  /**
   * Validate element definitions
   */
  private static validateElements(
    elements: any[],
    path: string,
    errors: ValidationError[],
    warnings: ValidationWarning[]
  ): void {
    if (!Array.isArray(elements)) {
      errors.push({
        path,
        message: "Elements must be an array",
        code: "INVALID_ELEMENTS_TYPE"
      });
      return;
    }

    elements.forEach((element, index) => {
      const elementPath = `${path}[${index}]`;

      // Validate AST path
      if (!element.astPath) {
        errors.push({
          path: `${elementPath}.astPath`,
          message: "Element AST path is required",
          code: "MISSING_ELEMENT_AST_PATH"
        });
      } else if (!this.isValidASTPath(element.astPath)) {
        errors.push({
          path: `${elementPath}.astPath`,
          message: "Invalid AST path format",
          code: "INVALID_AST_PATH"
        });
      }

      // Validate element type
      if (!element.type) {
        errors.push({
          path: `${elementPath}.type`,
          message: "Element type is required",
          code: "MISSING_ELEMENT_TYPE"
        });
      }

      // Validate source location
      if (!element.sourceLocation) {
        warnings.push({
          path: `${elementPath}.sourceLocation`,
          message: "Element source location is recommended",
          code: "MISSING_SOURCE_LOCATION"
        });
      }

      // Recursively validate children
      if (element.children) {
        this.validateElements(element.children, `${elementPath}.children`, errors, warnings);
      }
    });
  }

  /**
   * Check if AST path format is valid
   */
  private static isValidASTPath(path: string): boolean {
    // AST paths should start with / and contain valid node selectors
    return /^\/[A-Za-z][A-Za-z0-9_]*(\[[A-Za-z0-9_.=\[\]]+\])?(\/[A-Za-z][A-Za-z0-9_]*(\[[A-Za-z0-9_.=\[\]]+\])?)*$/.test(path);
  }

  /**
   * Validate AST path uniqueness across project
   */
  static validateASTPathUniqueness(project: ChimeraProject): ValidationResult {
    const errors: ValidationError[] = [];
    const warnings: ValidationWarning[] = [];
    const pathMap = new Map<string, string>();

    this.collectASTPathsFromTree(project.tree, pathMap, errors);

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  /**
   * Collect all AST paths from tree for uniqueness validation
   */
  private static collectASTPathsFromTree(
    node: any,
    pathMap: Map<string, string>,
    errors: ValidationError[],
    currentPath = "tree"
  ): void {
    // Check component-level paths
    if (node.type === 'Component') {
      // Check hook paths
      if (node.hooks) {
        node.hooks.forEach((hook: any, index: number) => {
          if (hook.astPath) {
            const existingLocation = pathMap.get(hook.astPath);
            if (existingLocation) {
              errors.push({
                path: `${currentPath}.hooks[${index}].astPath`,
                message: `Duplicate AST path found: ${hook.astPath} (also used in ${existingLocation})`,
                code: "DUPLICATE_AST_PATH"
              });
            } else {
              pathMap.set(hook.astPath, `${currentPath}.hooks[${index}]`);
            }
          }
        });
      }

      // Check element paths
      if (node.definition?.elements) {
        this.collectElementPaths(node.definition.elements, pathMap, errors, `${currentPath}.definition.elements`);
      }
    }

    // Recursively check children
    if (node.children) {
      node.children.forEach((child: any, index: number) => {
        this.collectASTPathsFromTree(child, pathMap, errors, `${currentPath}.children[${index}]`);
      });
    }
  }

  /**
   * Collect AST paths from elements recursively
   */
  private static collectElementPaths(
    elements: any[],
    pathMap: Map<string, string>,
    errors: ValidationError[],
    currentPath: string
  ): void {
    elements.forEach((element, index) => {
      if (element.astPath) {
        const existingLocation = pathMap.get(element.astPath);
        if (existingLocation) {
          errors.push({
            path: `${currentPath}[${index}].astPath`,
            message: `Duplicate AST path found: ${element.astPath} (also used in ${existingLocation})`,
            code: "DUPLICATE_AST_PATH"
          });
        } else {
          pathMap.set(element.astPath, `${currentPath}[${index}]`);
        }
      }

      // Recursively check children
      if (element.children) {
        this.collectElementPaths(element.children, pathMap, errors, `${currentPath}[${index}].children`);
      }
    });
  }
}
