import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { 
  Project, 
  ParseStatus, 
  ProjectStats, 
  Log, 
  ChimeraProject 
} from "@shared/schema";

export function useChimera() {
  const [currentProjectId, setCurrentProjectId] = useState<number | null>(null);
  const queryClient = useQueryClient();

  // Create project mutation
  const createProjectMutation = useMutation({
    mutationFn: async (data: { name: string; rootDirectory: string }) => {
      const response = await apiRequest("POST", "/api/projects", data);
      return response.json();
    },
    onSuccess: (project: Project) => {
      setCurrentProjectId(project.id);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
    },
  });

  // Process files mutation
  const processFilesMutation = useMutation({
    mutationFn: async (files: File[]) => {
      if (!currentProjectId) throw new Error("No project selected");
      
      const formData = new FormData();
      files.forEach(file => formData.append("files", file));
      
      const response = await fetch(`/api/projects/${currentProjectId}/process`, {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) throw new Error("Failed to process files");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", currentProjectId, "status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", currentProjectId, "stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", currentProjectId, "logs"] });
    },
  });

  // Queries
  const { data: project } = useQuery({
    queryKey: ["/api/projects", currentProjectId],
    enabled: !!currentProjectId,
  });

  const { data: parseStatus } = useQuery<ParseStatus>({
    queryKey: ["/api/projects", currentProjectId, "status"],
    enabled: !!currentProjectId,
    refetchInterval: 2000, // Poll every 2 seconds
  });

  const { data: stats } = useQuery<ProjectStats>({
    queryKey: ["/api/projects", currentProjectId, "stats"],
    enabled: !!currentProjectId,
  });

  const { data: logs } = useQuery<Log[]>({
    queryKey: ["/api/projects", currentProjectId, "logs"],
    enabled: !!currentProjectId,
    refetchInterval: 1000, // Poll every second for logs
  });

  // Helper functions
  const createProject = async (name: string, rootDirectory: string = "client") => {
    return createProjectMutation.mutateAsync({ name, rootDirectory });
  };

  const processFiles = async (files: File[]) => {
    if (!currentProjectId) {
      // Auto-create project if none exists
      await createProject("New Project");
    }
    return processFilesMutation.mutateAsync(files);
  };

  const exportSchema = async () => {
    if (!currentProjectId) return;
    
    const response = await fetch(`/api/projects/${currentProjectId}/results`);
    const data = await response.json();
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chimera-schema.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const runPipeline = async () => {
    if (!currentProjectId) return;
    
    await apiRequest("POST", `/api/projects/${currentProjectId}/validate`);
    queryClient.invalidateQueries({ queryKey: ["/api/projects", currentProjectId, "logs"] });
  };

  return {
    project,
    parseStatus: parseStatus || {
      astGeneration: 'pending',
      hookDetection: 'pending', 
      importAnalysis: 'pending',
      schemaValidation: 'pending'
    },
    stats: stats || {
      components: 0,
      hooks: 0,
      imports: 0,
      astPaths: 0
    },
    logs: logs || [],
    createProject,
    processFiles,
    exportSchema,
    runPipeline,
    isProcessing: processFilesMutation.isPending,
    currentProjectId,
    setCurrentProjectId,
  };
}
